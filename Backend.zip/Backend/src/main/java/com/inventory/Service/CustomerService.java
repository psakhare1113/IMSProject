package com.inventory.Service;


import com.inventory.DTO.CustomerRequestDTO;
import com.inventory.Entity.Customer;

import java.util.List;

public interface CustomerService {
    Customer createCustomer(CustomerRequestDTO customerRequestDTO);
    Customer getCustomerById(Long id);
    Customer getCustomerByRefNumber(String customerRefNumber);

    List<Customer> getCustomersByArea(String area);

    long getCustomerCountByArea(String area);
}