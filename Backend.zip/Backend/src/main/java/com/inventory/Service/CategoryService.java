package com.inventory.Service;

import com.inventory.Entity.Category;
import com.inventory.Entity.SubCategory;
import java.util.List;

public interface CategoryService {
    Category createCategory(Category category);

    SubCategory createSubCategory(Long categoryId, SubCategory subCategory);

    List<Category> getAllCategories();

    List<SubCategory> getSubCategoriesByCategory(Long categoryId);
}
