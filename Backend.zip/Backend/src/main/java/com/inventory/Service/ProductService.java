package com.inventory.Service;

import com.inventory.Entity.Product;

import java.util.List;

public interface ProductService {
    List<Product> getProductsByCategory(String categoryName);

    List<Product> getProductsBySubCategory(String name);

    Product createProduct(Product product);
    List<Product> getAllProducts();
}
