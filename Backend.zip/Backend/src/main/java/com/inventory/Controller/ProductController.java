package com.inventory.Controller;

import com.inventory.Entity.Category;
import com.inventory.Entity.Product;
import com.inventory.Entity.SubCategory;
import com.inventory.Service.CategoryService;
import com.inventory.Service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/products")
@RequiredArgsConstructor
public class ProductController {


    private final CategoryService categoryService;
    private final ProductService productService;

    //  Add a new Product (also logs stock movement internally)
    @PostMapping
    public ResponseEntity<Product> createProduct(@RequestBody Product product) {
        Product savedProduct = productService.createProduct(product);
        return ResponseEntity.ok(savedProduct);
    }

    //  Get all products
    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        return ResponseEntity.ok(productService.getAllProducts());
    }

    //  Get products by Category
    @GetMapping("/byCategory/{categoryName}")
    public ResponseEntity<List<Product>> getProductsByCategory(@PathVariable String categoryName) {
        return ResponseEntity.ok(productService.getProductsByCategory(categoryName));
    }

    //  Get products by SubCategory
    @GetMapping("/bySubCategory/{name}")
    public ResponseEntity<List<Product>> getProductsBySubCategory(@PathVariable String name) {
        return ResponseEntity.ok(productService.getProductsBySubCategory(name));
    }
}
