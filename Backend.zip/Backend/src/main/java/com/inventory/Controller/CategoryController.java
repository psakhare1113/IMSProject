package com.inventory.Controller;

import com.inventory.Entity.Category;
import com.inventory.Entity.SubCategory;
import com.inventory.Service.CategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/categories")
@RequiredArgsConstructor
public class CategoryController {

    private final CategoryService categoryService;

    @PostMapping
    public ResponseEntity<Category> createCategory(@RequestBody Category category) {
        return ResponseEntity.ok(categoryService.createCategory(category));
    }

    @PostMapping("/{categoryId}/subcategories")
    public ResponseEntity<SubCategory> createSubCategory(@PathVariable Long categoryId, @RequestBody SubCategory subCategory) {
        return ResponseEntity.ok(categoryService.createSubCategory(categoryId, subCategory));
    }

    @GetMapping("/{categoryId}/subcategories")
    public ResponseEntity<List<SubCategory>> getSubCategoriesByCategory(@PathVariable Long categoryId) {
        return ResponseEntity.ok(categoryService.getSubCategoriesByCategory(categoryId));
    }
    @GetMapping("/Categories")
    public ResponseEntity<List<Category>> getAllCategories() {
        return ResponseEntity.ok(categoryService.getAllCategories());


    }
}
