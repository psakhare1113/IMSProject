package com.inventory.ServiceImpl;

import com.inventory.Entity.Product;
import com.inventory.Entity.StockMovement;
import com.inventory.Repository.CategoryRepository;
import com.inventory.Repository.ProductRepository;
import com.inventory.Repository.StockMovementRepository;
import com.inventory.Service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final StockMovementRepository stockMovementRepository;
    private final CategoryRepository categoryRepository;

   /* @Override
    public Product createProduct(Product product) {
        // Validate category exists
        if (product.getCategory() != null && product.getCategory().getId() != null) {
            categoryRepository.findById(product.getCategory().getId())
                    .orElseThrow(() -> new RuntimeException("Category not found with ID: " + product.getCategory().getId()));
        }

        // Save product
        Product savedProduct = productRepository.save(product);

        // Log stock movement
        StockMovement movement = new StockMovement();
        movement.setProduct(savedProduct);
        movement.setMovementDate(LocalDateTime.now());
        movement.setMovementType("ADD");
        movement.setQuantity(savedProduct.getAvailableQuantity());

        stockMovementRepository.save(movement);

        return savedProduct;
    }
*/

    @Override
    public Product createProduct(Product product) {
        // Save product
        Product savedProduct = productRepository.save(product);

        // Log stock movement
        StockMovement movement = new StockMovement();
        movement.setProduct(savedProduct);
        movement.setMovementDate(LocalDateTime.now());
        movement.setMovementType("ADD");
        movement.setQuantity(savedProduct.getAvailableQuantity());

        stockMovementRepository.save(movement);

        return savedProduct;
    }



    @Override
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    @Override
    public List<Product> getProductsByCategory(String categoryName) {
        return productRepository.findByCategory_NameIgnoreCase(categoryName);
    }

    @Override
    public List<Product> getProductsBySubCategory(String subCategoryName) {
        return productRepository.findBySubCategory_NameIgnoreCase(subCategoryName);
    }

}
