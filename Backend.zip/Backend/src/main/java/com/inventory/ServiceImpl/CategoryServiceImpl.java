package com.inventory.ServiceImpl;

import com.inventory.Entity.Category;
import com.inventory.Entity.SubCategory;
import com.inventory.Repository.CategoryRepository;
import com.inventory.Repository.SubCategoryRepository;
import com.inventory.Service.CategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CategoryServiceImpl implements CategoryService {

    private final CategoryRepository categoryRepository;
    private final SubCategoryRepository subCategoryRepository;

    // Create a new Category
    public Category createCategory(Category category) {
        return categoryRepository.save(category);
    }

    // Create SubCategory under a Category
    public SubCategory createSubCategory(Long categoryId, SubCategory subCategory) {
        Category category = categoryRepository.findById(categoryId)
                .orElseThrow(() -> new RuntimeException("Category not found with ID: " + categoryId));

        subCategory.setCategory(category);
        return subCategoryRepository.save(subCategory);
    }

    // Get all Categories
    public List<Category> getAllCategories() {
        return categoryRepository.findAll();
    }
    // Get SubCategories by Category
    public List<SubCategory> getSubCategoriesByCategory(Long categoryId) {
        return subCategoryRepository.findByCategoryId(categoryId);
    }

}