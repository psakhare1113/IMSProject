package com.inventory.Entity;


import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
@Entity
@Table(name = "products")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String sku;

    @Column(unique = true)
    private String name;
    private String description;
    private double price;

    private int availableQuantity;


    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "category_id",nullable = true)
    private Category category;

    @ManyToOne
    @JsonIgnore
    @JoinColumn(name = "subcategory_id",nullable = true)
    private SubCategory subCategory;


    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL, orphanRemoval = true)
    @JsonIgnore
    private List<StockMovement> stockMovements = new ArrayList<>();
}
